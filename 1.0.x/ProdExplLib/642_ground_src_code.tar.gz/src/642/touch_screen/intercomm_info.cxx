/*
 * Copyright (c) 2012，MIT
 * All right reserved.
 *
 * 文件名称： intercomm_info.cxx
 * 文件标识：
 * 摘    要： 触摸屏对讲信息函数处理
 *
 * 当前版本： V1.0.0
 * 作    者： wilson
 * 完成日期：2013-01-11
 *
 * 取代版本：
 * 原作者  ：
 * 完成日期：
 */
#include "intercomm_info.h"


