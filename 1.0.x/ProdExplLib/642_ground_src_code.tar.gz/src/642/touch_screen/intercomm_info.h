/*
 * Copyright (c) 2012，MIT
 * All right reserved.
 *
 * 文件名称： intercomm_info.h
 * 文件标识：
 * 摘    要： 触摸屏对讲信息函数处理
 *
 * 当前版本： V1.0.0
 * 作    者： wilson
 * 完成日期：2013-01-11
 *
 * 取代版本：
 * 原作者  ：
 * 完成日期：
 */
#ifndef INTERCOMMINFO_H
#define INTERCOMMINFO_H


#include "ts_type.h"
extern d2p_table_t  D2P_Table[20];

#endif
