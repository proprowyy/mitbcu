/*
 * Copyright (c) 2012，MIT
 * All right reserved.
 *
 * 文件名称： zhw_dev_selftest_module.c
 * 文件标识：
 * 摘    要： 设备自检模块主函数
 *
 * 当前版本： V1.0.0
 * 作    者： 周魏
 * 完成日期：2013-03-26
 *
 * 取代版本：
 * 原作者  ：
 * 完成日期：
 *
 */
#include "zhw_dev_selftest_module.h"





int ZhwDevTestModule(udp_heart_socket_buffer_t udp_heart_buffer)
{




	return 0;
}
