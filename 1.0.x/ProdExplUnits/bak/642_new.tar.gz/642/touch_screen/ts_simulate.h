/*
 * ts_simulate.h
 *
 *  Created on: 2013-6-20
 *      Author: benty
 */

#ifndef TS_SIMULATE_H_
#define TS_SIMULATE_H_
#include "station_info.h"
#include "intercomm_info.h"
#include "data_struct.h"
#include <FL/Fl_Group.H>
#include <FL/Fl_Button.H>
#define CHINESELENGTH 24
#define ENGLISHLENGTH 12

//#define TMSSIZE  256 //4096
//#define TMSSTATIC 128 //512


typedef struct
{
	int state_id;
}state_process_tt;


#endif /* TS_SIMULATE_H_ */
